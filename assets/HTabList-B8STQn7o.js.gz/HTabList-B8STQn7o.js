import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-ClaTH3RA.js";import"./index-fOI-6dkn.js";import"./use-resolve-button-type-CwNTVn65.js";export{o as default};
