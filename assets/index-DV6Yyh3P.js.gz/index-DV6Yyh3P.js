import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Ya3T0Qpn.js";import"./usePagination-Dofy2ZY-.js";import"./index-DCNrAvYe.js";export{o as default};
