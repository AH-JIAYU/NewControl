import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-DKcVDLMl.js";import"./index-AYGfxCO1.js";import"./use-resolve-button-type-DzgJX-cH.js";export{o as default};
