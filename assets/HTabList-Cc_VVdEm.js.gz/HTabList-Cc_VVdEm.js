import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-v4YmORqp.js";import"./index-BTP43HjK.js";import"./use-resolve-button-type-DFTQPm6v.js";export{o as default};
