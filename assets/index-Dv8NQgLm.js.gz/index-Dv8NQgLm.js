import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-ogh2xT2D.js";import"./usePagination--YXRMFtL.js";import"./index-C0vqyojX.js";export{o as default};
