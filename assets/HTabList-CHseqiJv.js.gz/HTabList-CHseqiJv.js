import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-CznfV5rI.js";import"./index-DE7GWU9V.js";import"./use-resolve-button-type-DGCJZtoM.js";export{o as default};
