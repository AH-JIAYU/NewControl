import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Ce0Tzepp.js";import"./setting_user-CztgqVvH.js";import"./index-8VIcFXwB.js";export{o as default};
