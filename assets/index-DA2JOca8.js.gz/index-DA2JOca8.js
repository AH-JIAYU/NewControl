import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Dx_pf5Wy.js";import"./usePagination-Ct4kBoPu.js";import"./index-CUKb-Uvd.js";export{o as default};
