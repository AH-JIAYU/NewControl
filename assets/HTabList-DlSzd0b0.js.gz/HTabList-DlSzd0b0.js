import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-BeHPPmYJ.js";import"./index-DC3paojg.js";import"./use-resolve-button-type-C2cx60ys.js";export{o as default};
