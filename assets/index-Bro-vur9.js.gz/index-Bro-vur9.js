import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Jn7t-sy4.js";import"./usePagination-DsvfPnxb.js";import"./index-BTP43HjK.js";export{o as default};
