import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-B7eF7V3x.js";import"./index-DOkv7lLq.js";import"./use-resolve-button-type-Ug2Pb5Hv.js";export{o as default};
