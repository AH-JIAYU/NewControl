import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-CUb8h6ez.js";import"./index-CUpiA7PJ.js";import"./use-resolve-button-type-CO1zMQGC.js";export{o as default};
