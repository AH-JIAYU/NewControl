import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DkG3GcPA.js";import"./setting_user-C4Efe3yz.js";import"./index-CNoZ28XD.js";export{o as default};
