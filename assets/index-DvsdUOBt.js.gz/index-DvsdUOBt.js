import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BgN7UIra.js";import"./setting_user-C7BsooGs.js";import"./index-DCn4g2j_.js";export{o as default};
