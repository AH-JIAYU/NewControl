import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-DQUaPgG1.js";import"./index-TNcU_1PK.js";import"./use-resolve-button-type-D-Nco4vU.js";export{o as default};
