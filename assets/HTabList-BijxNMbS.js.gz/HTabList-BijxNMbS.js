import{_ as o}from"./HTabList.vue_vue_type_script_setup_true_lang-BR_XMA7n.js";import"./index-CUKb-Uvd.js";import"./use-resolve-button-type-BpJPf-Nq.js";export{o as default};
