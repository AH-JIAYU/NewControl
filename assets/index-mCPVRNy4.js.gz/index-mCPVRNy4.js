import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-Csk_UwgX.js";import"./index-C0vqyojX.js";export{m as default};
