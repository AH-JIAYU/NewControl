import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CyQAK1XY.js";import"./usePagination-Da8pRluS.js";import"./index-CS0OZ-B6.js";export{o as default};
